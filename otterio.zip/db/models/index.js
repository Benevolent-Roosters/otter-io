module.exports.Auth = require('./auths');
module.exports.Profile = require('./profiles');
module.exports.User = require('./users');
module.exports.Board = require('./boards');
module.exports.Panel = require('./panels');
module.exports.Ticket = require('./tickets');