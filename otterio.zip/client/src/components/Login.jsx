import React from 'react';


const Login = (props) => {
  return (
    <div>Pie</div>
  );
};

const mapStateToProps = (state) => {
  return {

  };
};

const mapDispatchToProps = (dispatch) => {
  return {
    
  };
};

export default Login;