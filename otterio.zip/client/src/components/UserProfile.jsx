import React from 'react';


const UserProfile = (props) => {
  return (
    <div>This is UserProfile</div>
  );
};

export default UserProfile;