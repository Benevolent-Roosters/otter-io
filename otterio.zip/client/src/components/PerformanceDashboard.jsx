import React from 'react';


const PerformanceDashboard = (props) => {
  return (
    <div>This is Performance DashBoard</div>
  );
};

export default PerformanceDashboard;